# extension/core/ui/

Plain scripts (not modules) that pages and content scripts share. Each one sets a global.

| File | Global | What it does |
| --- | --- | --- |
| `header.js` | `KidTubeHeader` | The apps header of **Custom Apps** (the extension; KidTube and Instagram are its apps): one bar with the logo and the version (a newer one above it, in blue: a tap installs it on Quetta, opens the install page on Orion, opens `chrome://extensions` for a copy from git), the **App \| site** switch of the running app (App \| YouTube, App \| Instagram; `mount(host, { siteView })` lets a page switch its own view), the connected profile and, on a site's own page, **Connect** (the account signed in there; the page reads it again first with `globalThis.KidTubeAccount.read`). The 🔔 button (its number: what still waits; red: something needs you) shows or hides the notifications where the parent is (`core/background/inbox.js`): one row each, `[type] [status] message [buttons] [count]`. Types: Error, Validation (a self-check), Data update (the AI run on the notes, posts waiting), My note (each note not sent yet: **Edit**, **Delete** (asks once more), **Send** that one note), App update (a newer version), System (what the header's last action said). The same problem again only counts up; on a new version it is sent again (try 2). Below the bar also: the GitHub connection, or the apps row (each app, dimmed while its site's account has no profile in it). Drawn in its own shadow root. Also `modeSwitch()`, the Parent / Kid switch of the apps' pages |
| `watch.js` | `KidTubeWatch` | The checks on a page (loaded first): screen checks, "no dead buttons", "the background answers", uncaught errors in KidTube's code. Results go to the background (`core/checks/`) |
| `boot.js` | — | Loaded first on the parent screens and the PIN page: if the page does not start, it shows the error on the page (the iPad has no developer console) |

`header.js` runs on YouTube too, so it never uses `innerHTML` (YouTube's Trusted Types policy refuses it).
