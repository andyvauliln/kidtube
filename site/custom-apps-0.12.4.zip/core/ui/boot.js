// Loaded first on the parent screens and the PIN page (a plain script): if the page fails to start, show why on
// it instead of a white page — the iPad has no developer console. The page's script sets window.kidtubeParentReady.
(() => {
  const show = (text) => {
    let box = document.getElementById('bootErr');
    if (!box) {
      box = document.createElement('pre');
      box.id = 'bootErr';
      box.style.cssText = 'white-space:pre-wrap;margin:16px;padding:12px;border-radius:10px;background:#fdecea;color:#b71c1c;font:13px/1.4 ui-monospace,monospace';
      (document.body || document.documentElement).append(box);
    }
    box.textContent += text + '\n';
  };
  addEventListener('error', (e) => show(`Error: ${e.message || e.target?.src || e.type} ${e.filename ? `(${e.filename.split('/').slice(-2).join('/')}:${e.lineno}:${e.colno})` : ''}`), true);
  addEventListener('unhandledrejection', (e) => show(`Error (async): ${e.reason?.message ?? e.reason} ${e.reason?.stack?.split('\n')[0] ?? ''}`));
  setTimeout(() => {
    if (window.kidtubeParentReady) return;
    show(`The parent screens did not start (Custom Apps ${chrome?.runtime?.getManifest?.().version ?? '?'}, ${navigator.userAgent}).\nPlease send a screenshot of this box.`);
    const W = globalThis.KidTubeWatch;
    if (W) {
      const t = new W.Expect();
      t.mismatch.push({ what: 'the page’s script', expected: 'started within 6 s', actual: 'did not start' });
      t.note('shown', document.getElementById('bootErr')?.textContent.slice(0, 1500) ?? '');
      W.send({ id: 'page.start', kind: 'screen', area: 'page', expect: 'A KidTube page starts within 6 s', code: [location.pathname], status: 'fail',
        mismatch: t.mismatch, evidence: t.evidence, ms: 6000, page: { path: location.pathname, tab: location.hash.slice(1) || null } });
    }
  }, 6000);
})();
